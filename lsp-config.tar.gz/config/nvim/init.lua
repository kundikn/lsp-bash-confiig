-- Lazy.nvim bootstrap
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
  print("⚠️ Lazy.nvim не найден, клонирую...")
  vim.fn.system({
    "git",
    "clone",
    "--filter=blob:none",
    "https://github.com/folke/lazy.nvim.git",
    lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

-- Загрузка всех плагинов
require("lazy").setup("plugins")

-- Общие настройки
vim.opt.number = true
vim.o.termguicolors = true
vim.cmd("colorscheme gruvbox")

-- Настройка LSP для Bash
local lspconfig = require("lspconfig")
local capabilities = require("cmp_nvim_lsp").default_capabilities()

lspconfig.bashls.setup({
  capabilities = capabilities,
  filetypes = { "sh", "bash" },
  cmd = { "bash-language-server", "start" },
  root_dir = require("lspconfig.util").root_pattern(".git", "*.sh", "."),
})

